# WiSync
Go to [Releases](https://github.com/CMakerA/WiSync/releases) and download the last for your device.
